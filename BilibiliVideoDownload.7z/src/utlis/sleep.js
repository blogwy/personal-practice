export default (timeountMS) => new Promise((resolve) => {
  setTimeout(resolve, timeountMS)
})
