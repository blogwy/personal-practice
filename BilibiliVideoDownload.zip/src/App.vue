<template>
  <div id="app">
    <LayoutHeader></LayoutHeader>
  </div>
</template>

<script>
import LayoutHeader from './components/Header'
export default {
  data () {
    return {}
  },
  components: {
    LayoutHeader
  },
  computed: {},
  watch: {},
  mounted () {},
  created () {},
  methods: {}
}
</script>

<style lang="less">
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}
</style>
