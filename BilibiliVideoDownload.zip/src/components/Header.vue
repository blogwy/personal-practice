<template>
  <header class="header">header</header>
</template>

<script>
export default {
  data () {
    return {}
  },
  components: {},
  computed: {},
  watch: {},
  mounted () {},
  created () {},
  methods: {}
}
</script>

<style scoped lang="less">
.header{
  height: 32px;
  border-bottom: #dddddd solid  1px;
  user-select: none;
  -webkit-app-region: drag;
}
</style>
