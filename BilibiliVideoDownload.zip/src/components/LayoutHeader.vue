<template>
  <div class="header fr ac jc">
    {{projectName}}
  </div>
</template>

<script>
const info = require('../../package.json')
export default {
  data () {
    return {
      projectName: info.name
    }
  },
  components: {},
  computed: {},
  watch: {},
  mounted () {},
  created () {},
  methods: {}
}
</script>

<style scoped lang="less">
.header{
  position: relative;
  box-sizing: border-box;
  height: 28px;
  -webkit-app-region: drag;
  color: @primary-color;
  font-weight: bold;
}
</style>
