let rp = require('request-promise');

// function test(aid) {
//   return rp('https://api.bilibili.com/x/web-interface/view?aid=' + aid);
// }

let aidArr = ['46300505','46342312','14248273','44671873','29069985'];

// (async function() {
//   for (let index = 0; index < 5; index++) {
//     let res = await rp('https://api.bilibili.com/x/web-interface/view?aid=' + aidArr[index]);
//     console.log(JSON.parse(res).data.title);
//     console.log(index);
//   }
// })()

(function (){
  for (let index = 0; index < 5; index++) {
    rp('https://api.bilibili.com/x/web-interface/view?aid='+ aidArr[index])
    .then(res => {
      console.log(JSON.parse(res).data.title);
      console.log(index);
      
    })
    
  }
})()
