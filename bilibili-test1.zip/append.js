let fs = require('fs');

fs.readdir('./utils/',function (err,files) {
  console.log(files);
  
})