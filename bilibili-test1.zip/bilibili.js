
let request = require('request');
let fs = require('fs');
let progress = require('progress-stream');
let ProgressBar  = require('./progress-bar');

let pb = new ProgressBar('下载进度', 50);

let str = progress({
  time: 200
});

var num = 0, total = 96658418;
str.on('progress', function(progress) {
  pb.render({
    completed: progress.transferred ? progress.transferred : num,
    total: total
  });
   // console.log(JSON.stringify(progress));
});

function downloadFile(uri,filename,aid,callback){
  let stream = fs.createWriteStream(filename);
  request({
    url: uri,
    headers: {
      'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.13; rv:56.0) Gecko/20100101 Firefox/56.0',
      'Accept': '*/*',
      'Accept-Language': 'en-US,en;q=0.5',
      'Accept-Encoding': 'gzip, deflate, br',
      'Range': 'bytes=0-',
      'Referer': 'http://www.bilibili.com/video/av'+ aid +'/',
      'Origin': 'https://www.bilibili.com',
      'Connection': 'keep-alive'
    }
  }).pipe(stream).on('close', callback);
}

let fileUrl = 'http://upos-hz-mirrorcosu.acgvideo.com/upgcxcode/71/65/51686571/51686571-1-64.flv?e=ig8euxZM2rNcNbUahbUVhoMB7zNBhwdEto8g5X10ugNcXBlqNxHxNEVE5XREto8KqJZHUa6m5J0SqE85tZvEuENvNC8xNEVE9EKE9IMvXBvE2ENvNCImNEVEK9GVqJIwqa80WXIekXRE9IMvXBvEuENvNCImNEVEua6m2jIxux0CkF6s2JZv5x0DQJZY2F8SkXKE9IB5QK==&deadline=1552760816&gen=playurl&nbs=1&oi=1961043209&os=cosu&platform=pc&trid=4a8bb06953824813b15d4a4cd4a21849&uipk=5&upsig=5122cc77075e58abbb664a23c7d3fd97';
let filename = 'test-2.flv';

let imgArr = [{
	"videoAid": "29702317",
	"videoTitle": "简单装机_bilibili-0",
	"videoLength": "6.92min",
	"videoSize": 55388201,
	"videoFormat": "flv",
	"url": "http://upos-hz-mirrorcosu.acgvideo.com/upgcxcode/71/65/51686571/51686571-1-32.flv?e=ig8euxZM2rNcNbhzhbUVhoMzhzNBhwdEto8g5X10ugNcXBlqNxHxNEVE5XREto8KqJZHUa6m5J0SqE85tZvEuENvNC8xNEVE9EKE9IMvXBvE2ENvNCImNEVEK9GVqJIwqa80WXIekXRE9IMvXBvEuENvNCImNEVEua6m2jIxux0CkF6s2JZv5x0DQJZY2F8SkXKE9IB5QK==&deadline=1552841495&gen=playurl&nbs=1&oi=1961043209&os=cosu&platform=pc&trid=af71d90b42ec4356803eacf97968833e&uipk=5&upsig=004f17af1a48aa6a2408cef38231615e"
}, {
	"videoAid": "29702317",
	"videoTitle": "简单装机_bilibili-1",
	"videoLength": "5.16min",
	"videoSize": 45140964,
	"videoFormat": "flv",
	"url": "http://upos-hz-mirrorcosu.acgvideo.com/upgcxcode/71/65/51686571/51686571-2-32.flv?e=ig8euxZM2rNcNbhjhbUVhoMz7bNBhwdEto8g5X10ugNcXBlqNxHxNEVE5XREto8KqJZHUa6m5J0SqE85tZvEuENvNC8xNEVE9EKE9IMvXBvE2ENvNCImNEVEK9GVqJIwqa80WXIekXRE9IMvXBvEuENvNCImNEVEua6m2jIxux0CkF6s2JZv5x0DQJZY2F8SkXKE9IB5QK==&deadline=1552841495&gen=playurl&nbs=1&oi=1961043209&os=cosu&platform=pc&trid=af71d90b42ec4356803eacf97968833e&uipk=5&upsig=d6f77d976f3232dff3d771179913c022"
}, {
	"videoAid": "29702317",
	"videoTitle": "简单装机_bilibili-2",
	"videoLength": "6.47min",
	"videoSize": 53104145,
	"videoFormat": "flv",
	"url": "http://upos-hz-mirrorwcsu.acgvideo.com/upgcxcode/71/65/51686571/51686571-3-32.flv?e=ig8euxZM2rNcNbhMhwdVhoMz7wdVhwdEto8g5X10ugNcXBlqNxHxNEVE5XREto8KqJZHUa6m5J0SqE85tZvEuENvNC8xNEVE9EKE9IMvXBvE2ENvNCImNEVEK9GVqJIwqa80WXIekXRE9IMvXBvEuENvNCImNEVEua6m2jIxux0CkF6s2JZv5x0DQJZY2F8SkXKE9IB5QK==&deadline=1552841495&gen=playurl&nbs=1&oi=1961043209&os=wcsu&platform=pc&trid=af71d90b42ec4356803eacf97968833e&uipk=5&upsig=7a32f0c87af8e65d2d1d6e435393555a"
}, {
	"videoAid": "29702317",
	"videoTitle": "简单装机_bilibili-3",
	"videoLength": "5.62min",
	"videoSize": 47659510,
	"videoFormat": "flv",
	"url": "http://upos-hz-mirrorcosu.acgvideo.com/upgcxcode/71/65/51686571/51686571-4-32.flv?e=ig8euxZM2rNcNbhBhbUVhoMz7WNBhwdEto8g5X10ugNcXBlqNxHxNEVE5XREto8KqJZHUa6m5J0SqE85tZvEuENvNC8xNEVE9EKE9IMvXBvE2ENvNCImNEVEK9GVqJIwqa80WXIekXRE9IMvXBvEuENvNCImNEVEua6m2jIxux0CkF6s2JZv5x0DQJZY2F8SkXKE9IB5QK==&deadline=1552841495&gen=playurl&nbs=1&oi=1961043209&os=cosu&platform=pc&trid=af71d90b42ec4356803eacf97968833e&uipk=5&upsig=fff85b9826c89c0ffab83d402874396d"
}, {
	"videoAid": "29702317",
	"videoTitle": "简单装机_bilibili-4",
	"videoLength": "7.56min",
	"videoSize": 62985254,
	"videoFormat": "flv",
	"url": "http://upos-hz-mirrorkodou.acgvideo.com/upgcxcode/71/65/51686571/51686571-5-32.flv?e=ig8euxZM2rNcNbhM7WdVhoMz7wUVhwdEto8g5X10ugNcXBlqNxHxNEVE5XREto8KqJZHUa6m5J0SqE85tZvEuENvNC8xNEVE9EKE9IMvXBvE2ENvNCImNEVEK9GVqJIwqa80WXIekXRE9IMvXBvEuENvNCImNEVEua6m2jIxux0CkF6s2JZv5x0DQJZY2F8SkXKE9IB5QK==&deadline=1552841495&gen=playurl&nbs=1&oi=1961043209&os=kodou&platform=pc&trid=af71d90b42ec4356803eacf97968833e&uipk=5&upsig=559c2a9a6efedd835693180e7540342b"
}];

let nameArr = [
  'video1.flv',
  'video2.flv',
  'video3.flv',
  'video4.flv',
  'video5.flv'
];
imgArr.forEach(function(item,index){
  downloadFile(item.url,item.videoTitle + '.'+item.videoFormat,item.videoAid,function(){
    console.log(item.videoTitle + '下载完成');
    
  })
})

// downloadFile(fileUrl,filename,function(){
//   console.log(filename+'下载完毕');
// });