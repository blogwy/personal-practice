const getUrl = require('./utils/getUrl');
const downloadFile = require('./utils/download');
const concat = require('./utils/concat');
const readlineSync = require('readline-sync');

let url,quality,qualityAll;

url = readlineSync.question('请输入视频URL...');

getUrl.getQuality(url)
    .then(response => {
      qualityAll = response;
      quality = readlineSync.keyInSelect(qualityAll,'选择要下载到清晰度？');
      getUrl.getDownloadUrl(url,qualityAll[quality])
          .then(res => {
            // 下载地址
            let len = res.length;
            console.log(JSON.stringify(res));
            res.forEach(function (item,index){
              downloadFile.get(item.videoAid,item.url,item.videoTitle+'.'+item.videoFormat,function () {
                console.log('\n' + item.videoTitle + '--下载完成');
                if(index+1 == len){
                  // 视频转吗
                  console.log('end');
                  //concat.cancatVideos(item.videoTitle,item.videoFormat,len);
                }
              })
            })
          })
          .catch(err => {
            console.log(err);
          })
    })
    .catch(error => {
      console.log(error);
    });

//
// qualityAll = getUrl.getQuality(url);
//
// quality = readlineSync.keyInSelect(qualityAll,'选择要下载到清晰度？');
//
// getUrl.getDownloadUrl(url,qualityAll[quality]);
