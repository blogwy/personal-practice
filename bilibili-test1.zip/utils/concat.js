let fluent_ffmpeg = require("fluent-ffmpeg");
let fs = require('fs');

let mergedVideo = fluent_ffmpeg();

function cancatVideos(name,format,len){
  console.log(JSON.stringify(getVideoNames(name,format,len)))
  let videoNames = getVideoNames(name,format,len).videoArr;
  videoNames.forEach(function(videoName){
    mergedVideo = mergedVideo.addInput(videoName);
  });

  mergedVideo.mergeToFile(getVideoNames(name,format,len).videoAll, '../tmp/')
  .on('error', function(err) {
    console.log('Error ' + err.message);
  })
  .on('progress', function(progress) {
  console.log(JSON.stringify(progress));
  })
  .on('end', function() {
    console.log('Finished!');
  });
}

function getVideoNames(name,format,len){
  let newName = getVideoName(name),videoArr = [];
  for (let index = 0; index < len; index++) {
    videoArr.push('./video/' + newName + index + '.' + format);
  }
  return {
    videoArr,
    videoAll: './video/' + newName + 'all.mp4'
  }
}

function getVideoName(str){
  var name = (str.split('.'))[0],
      newName = name.slice(0,name.length-1);
  return newName;
}

module.exports = {
  cancatVideos: cancatVideos
}