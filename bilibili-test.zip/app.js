const getUrl = require('./utils/getUrl');

getUrl.getUrl('https://www.bilibili.com/video/av45850131/');
