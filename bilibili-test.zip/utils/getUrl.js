let rp = require('request-promise');

const urlToAid = url => {
  let check = url.split("/");
  for( let i=0,len=check.length; i<len; i++ ){
    if(check[i].indexOf('av') >= 0 && !isNaN(parseInt(check[i].replace('av','')))){
      let aid = check[i].replace('av','');
      return aid;
    }
  }
}


const getUrl = async url => {
  let aid = urlToAid(url),
      videoInfo = await rp(`https://api.bilibili.com/x/web-interface/view?aid=${aid}`),
      cid = JSON.parse(videoInfo).data.cid;
  console.log(aid,cid);
  
}


module.exports = {
  getUrl: getUrl
}